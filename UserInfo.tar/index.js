// Write your JS code here
import './index.css'

const UserInfo = () => (
  <div className="infoContainer">
    <img
      src="https://assets.ccbp.in/frontend/react-js/profile-img.png"
      className="user-pic"
      alt="profile"
    />
    <div className="text-container">
      <h1>Wade Warren</h1>
      <p>Software developer at UK</p>
    </div>
  </div>
)
export default UserInfo
